
SUBMISSION BY:
Waquar Shamsi MT20073
Reshan Faraz Phd19006


Q1.
Dependencies:
	sklearn.cluster.KMeans
	pickle
	sklearn.preprocessing.StandardScaler
	sklearn.metrics.accuracy_score
	sklearn.metrics.recall_score
	sklearn.metrics.precision_score
	sklearn.metrics.f1_score
	sklearn.metrics.confusion_matrix
	matplotlib.pyplot
	numpy
	itertools.permutations
	pandas
	sklearn.decomposition.PCA
	sklearn.model_selection.train_test_split
	seaborn
Launch Respective .py files for part a,b,c and d.
Dataset is to present in 'Dataset/' directory
Report.pdf is to report everything.




Q2
##############################################################
##############################################################


1-Just run the Q2_21_A4.py file and get results for Question 2. 

2-All Dataset file(yelp_labelled) must present in same folder. Also the userSVM.py and 
 must present in the same folder where the python code is present.

3-You need to have following libraries:
a- pandas
b- numpy
c- sklearn : MultinomialNB, confusion_matrix ,CountVectorizer, accuracy_score, StratifiedShuffleSplit ,accuracy_score
d - re
e - nltk : stopwords,PorterStemmer
f - os


4-All the Questions runs sequentially.

6-Report(A3_group_21_Report.pdf) contain all the analysis,graph and explanation of every question including preprocessing
 of data.
##############################################################
##############################################################

