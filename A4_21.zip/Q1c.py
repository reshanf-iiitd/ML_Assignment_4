#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Nov 13 18:48:08 2020

@author: Waquar Shamsi
"""
#IMPORT LIBRARIES
from sklearn.cluster import KMeans
import pickle
from sklearn.preprocessing import StandardScaler
import seaborn as sns
from sklearn.decomposition import PCA

#LOAD DATA USING PICKLE
train_set = open('iris_train','rb')#Load the Dataset Split in Q1
df = pickle.load(train_set)


#DROP LABEL COLUMN AS NOT REQUIRED FOR FINDING CLUSTERS
X = df.drop(['label'],axis=1)

#FEATURE SCALING - REQUIRED FOR KMEANS
scale = StandardScaler()
X_scaled = scale.fit_transform(X)

#TRAIN THE KMEANS MODEL WITH OPTIMAL NUMBER OF k FOUND IN part b
kmeans = KMeans(n_clusters=3,verbose=1)
kmeans.fit(X_scaled)

#PREDICT USING THE MODEL for TRAINING SET
preds = kmeans.predict(X_scaled)

#APPLY PCA TO REDUCE THE NUMBER OF FEATURES TO 2
pca = PCA(n_components=2)
X_pca = pca.fit_transform(X_scaled)
#print(X_pca.shape)      # (105, 2) reduced to two features


#PLOT THE SCATTERPLOT
print("SCATTERPLOT FOR CLUSTERS IN IRIS DATASET WITH K=3")
sns.scatterplot(
        x=X_pca[:,0],
        y=X_pca[:,1],
        hue=preds,
        legend="full")
