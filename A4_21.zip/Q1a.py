#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Nov 13 13:57:04 2020

@author: Waquar Shamsi
"""
from sklearn.model_selection import train_test_split
import pandas as pd
import pickle

#Load the CSV file using Pandas ( Identified its a CSV file by opening it in text-editor )
df = pd.read_csv('Dataset/iris.data',header=None) #Used header as None, since otherwise it takes first row as header
#print(df) # Observed that number of features = 4 and labels = 1

#must reduce the number of features, to plot
#sns.scatter()

#ENUMERATE LABELS
unique_labels = df[4].unique()
df[4] = df[4].replace(unique_labels,list(range(len(unique_labels))))
#df[4] = df[4].replace(unique_labels,[2,1,0])


#SPLIT THE DATASET IN REQUIRED RATIO
X_train, X_test, y_train, y_test = train_test_split(df.drop([4],axis=1),df.filter([4]),test_size=0.3,stratify=df.filter([4]))
#print(X_train,y_train)  #105 samples in train_set i.e., 70% of all samples


#CREATE A DATAFRAME FOR TRAIN SET
train_df = pd.DataFrame(X_train,columns=list(range(X_train.shape[1])))
train_df['label']=y_train


#print(train_df)

#SAVE TRAIN SET
iris_train = open('iris_train', 'wb')
pickle.dump(train_df,iris_train)
print("Saved Train Set")

#CREATE A DATAFRAME FOR TEST SET
test_df = pd.DataFrame(X_test,columns=list(range(X_test.shape[1])))
test_df['label']=y_test
print("Saved Test Set")
#print(test_df)


#SAVE TEST SET
iris_test = open('iris_test', 'wb')
pickle.dump(test_df,iris_test)

'''
iris_test = open('iris_test', 'rb')
test_loaded=pickle.load(iris_test)
iris_train = open('iris_train', 'rb')
train_loaded=pickle.load(iris_train)

print(test_df,test_loaded)
print(train_df,train_loaded)
'''
