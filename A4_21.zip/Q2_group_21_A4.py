import pandas as pd
from sklearn.naive_bayes import MultinomialNB
from sklearn.model_selection import StratifiedShuffleSplit
from sklearn.metrics import confusion_matrix
import nltk
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.utils import shuffle
from sklearn.metrics import accuracy_score
from sklearn.model_selection import train_test_split
from sklearn import metrics
import numpy as np
import os
import heapq 
import re
import nltk
from nltk.corpus import stopwords
from nltk.stem.porter import PorterStemmer
nltk.download('stopwords')
nltk.download('punkt')

def Q2():

	colm = ["Review" , "Love"]
	data = pd.read_csv('yelp_labelled.txt',header=None,error_bad_lines=False,delimiter = '\t',quoting=3,names=colm)
	data['Review'] = data['Review'].str.lower()    ############# LOWER DONE
	data['Review'] = data['Review'].str.replace('[^\w\s]','')       ########## Removing Punctions
	corpus = []
	for i in range(0, 1000):
	    review = data['Review'][i]
	    review = review.split()
	    ps = PorterStemmer()
	    review = [ps.stem(word) for word in review if not word in set(stopwords.words('english'))]   ######## RemovingStopword
	    review = ' '.join(review)
	    corpus.append(review)

	y = data['Love']

	################################         Q3-3     
	# cv = CountVectorizer(max_features = 1000)
	# X = cv.fit_transform(corpus).toarray()
	# y = data['Love'].values

	############################################                     LAST EDIT #########################################

	word2count = {} 
	for datas in corpus: 
	    words = nltk.word_tokenize(datas) 
	    for word in words: 
	        if word not in word2count.keys(): 
	            word2count[word] = 1
	        else: 
	            word2count[word] += 1

	# print(len(word2count))

	freq_words = heapq.nlargest(1300, word2count, key=word2count.get)

	X = [] 
	for data in corpus: 
	    vector = [] 
	    for word in freq_words: 
	        if word in nltk.word_tokenize(data): 
	            vector.append(1) 
	        else: 
	            vector.append(0) 
	    X.append(vector) 
	X = np.asarray(X) 


	# print(freq_words)

	sss = StratifiedShuffleSplit(n_splits=5, test_size=0.3, random_state=0)
	sss.get_n_splits(X, y)
	for train_index, test_index in sss.split(X, y):
	  X_train, X_test = X[train_index], X[test_index]
	  y_train, y_test = y[train_index], y[test_index]



	classifier = MultinomialNB(alpha=1)
	classifier.fit(X_train, y_train)

	########################################  Q-5 for testing aaccuracy
	y_pred = classifier.predict(X_test)


	cm = confusion_matrix(y_test, y_pred)
	print ("Confusion Matrix Validation:\n",cm)

	score1 = accuracy_score(y_test,y_pred)
	print("\n")
	print(" Validation Accuracy is ",round(score1*100,2),"%")


	##############for training Accuracy
	y_pred = classifier.predict(X_train)


	cm = confusion_matrix(y_train, y_pred)
	print ("Confusion Matrix for Training :\n",cm)

	score1 = accuracy_score(y_train,y_pred)
	print("\n")
	print("Training Accuracy is ",round(score1*100,2),"%")

	print("\n\n")
	print("####################################################################################")
	print("----------------List of Misclassified Review for Training dataset-------------------" )
	print("####################################################################################")

	yy = np.asarray(y_train)
	misclassified = np.where(yy != classifier.predict(X_train))
	# print(misclassified)
	# print(len(misclassified))
	x=misclassified[:][0]
	for i in range(0,1000):
	  if i in x:
	    print(corpus[i])

	print("\n\n")
	print("####################################################################################")
	print("----------------List of Misclassified Review for Validation dataset-----------------" )
	print("####################################################################################")
	yy = np.asarray(y_test)
	misclassified = np.where(yy != classifier.predict(X_test))
	# print(misclassified)
	# print(len(misclassified))
	x=misclassified[:][0]
	for i in range(0,1000):
	  if i in x:
	    print(corpus[i])



if __name__ == "__main__":
    print("PhD19006")
    print("MT20073")
    Q2()

