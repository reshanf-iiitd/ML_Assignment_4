#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Nov 13 19:27:44 2020

@author: Waquar SHamsi
"""
#IMPORT LIBRARIES
from sklearn.cluster import KMeans
import pickle
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import accuracy_score
from sklearn.metrics import recall_score
from sklearn.metrics import precision_score
from sklearn.metrics import f1_score
from sklearn.metrics import confusion_matrix
import matplotlib.pyplot as plt
import numpy as np
from itertools import permutations
import pandas as pd

#LOAD DATA USING PICKLE
train_set = open('iris_train','rb')#Load the Dataset Split in Q1
df = pickle.load(train_set)

#DROP LABEL COLUMN AS NOT REQUIRED FOR FINDING CLUSTERS
X = df.drop(['label'],axis=1)
y = df.filter(['label'])
df['label'] = pd.to_numeric(df['label'])

#FEATURE SCALING - REQUIRED FOR KMEANS
scale = StandardScaler()
X_scaled = scale.fit_transform(X)

#TRAIN THE KMEANS MODEL WITH OPTIMAL NUMBER OF k FOUND IN part b
kmeans = KMeans(n_clusters=3,verbose=1)
kmeans.fit(X_scaled)

#PREDICT USING THE MODEL for TRAINING SET
train_preds = kmeans.predict(X_scaled)

#GET THE CORRECT LABELS
classes = y['label'].unique()
permutations = set(permutations(classes))
max_acc=0
best_per=[]
for per in permutations:
    #print(y['label'].to_numpy().transpose())
    y_t= y['label'].replace(np.unique(train_preds),per)
    #print(y_t.to_numpy().transpose())
    acc = accuracy_score(y_t,train_preds)
    if max_acc < acc:
        max_acc = acc
        best_per = per
#Final Transform using Best Accuracy to Match KMeans Classes
y_t= y['label'].replace(np.unique(train_preds),best_per)    

#PRINT METRICS
print("\nFOR TRAINING SET")
print("ACCURACY:\t",accuracy_score(y_t,train_preds))
print("PRECISION:\t",precision_score(y_t,train_preds,average='weighted'))
print("RECALL:\t\t",recall_score(y_t,train_preds,average='weighted'))
print("F1 SCORE:\t",f1_score(y_t,train_preds,average='weighted'))

#CONFUSION MATRIX
print("CONFUSION MATRIX")
cm = confusion_matrix(y_t, train_preds)
# Plot confusion matrix
plt.imshow(cm,cmap='Blues')
plt.xlabel("Predicted")
plt.ylabel("Actual")
plt.xticks(np.unique(y))
plt.yticks(np.unique(y))
plt.show()


######################## NOW FOR TEST SET ########################


#LOAD TEST DATA USING PICKLE
test_set = open('iris_test','rb')#Load the Dataset Split in Q1
df = pickle.load(test_set)

#DROP LABEL COLUMN AS NOT REQUIRED FOR FINDING CLUSTERS
X = df.drop(['label'],axis=1)
y = df.filter(['label'])

#FEATURE SCALING - REQUIRED FOR KMEANS
scale = StandardScaler()
X_scaled = scale.fit_transform(X)


#PREDICT USING THE MODEL for TEST SET
test_preds = kmeans.predict(X_scaled)

#Transform using Best Accuracy to Match KMeans Classes
y_t= y['label'].replace(np.unique(test_preds),best_per)

#PRINT METRICS
print("\nFOR TESTING SET") 
print("ACCURACY:\t",accuracy_score(y_t,test_preds))
print("PRECISION:\t",precision_score(y_t,test_preds,average='weighted'))
print("RECALL:\t\t",recall_score(y_t,test_preds,average='weighted'))
print("F1 SCORE:\t",f1_score(y_t,test_preds,average='weighted'))

#CONFUSION MATRIX
print("CONFUSION MATRIX")
cm = confusion_matrix(y_t, test_preds)
# Plot confusion matrix
plt.imshow(cm,cmap='Blues')
plt.xlabel("Predicted")
plt.ylabel("Actual")
plt.xticks(np.unique(y))
plt.yticks(np.unique(y))
plt.show()

#print(y.to_numpy().transpose(),test_preds)
