#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Nov 13 15:49:24 2020

@author: Waquar Shamsi
"""
#IMPORT LIBRARIES
from sklearn.cluster import KMeans
import pickle
from sklearn.preprocessing import StandardScaler
import matplotlib.pyplot as plt

#LOAD DATA USING PICKLE
train_set = open('iris_train','rb')#Load the Dataset Split in Q1
df = pickle.load(train_set)

#DROP LABEL COLUMN AS NOT REQUIRED FOR FINDING CLUSTERS
X = df.drop(['label'],axis=1)

#FEATURE SCALING - REQUIRED FOR KMEANS
scale = StandardScaler()
X_scaled = scale.fit_transform(X)

errors=[] #THE LIST TO HOLD THE SSE FOR EACH VALUE OF K
k_range = list(range(1,16))
#PERFORM KMEANS FOR A RANGE OF K VALUES
for k in k_range:
    kmeans = KMeans(n_clusters=k,verbose=1)
    kmeans.fit(X_scaled)
    errors.append(kmeans.inertia_)

#PLOT FOR NUMBER OF CLUSTERS 'K' vs SUM OF SQURRED ERROR
plt.plot(k_range,errors)
plt.title("NUMBER OF CLUSTERS 'K' vs SUM OF SQURRED ERRORS")
plt.xlabel("NUMBER OF CLUSTERS 'K'")
plt.xticks(list(range(16)))
plt.ylabel("SUM OF SQURRED ERRORS")
plt.show()



